package com.kanush_productions.drawingapp

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.View
import androidx.appcompat.widget.ViewFactory
import com.kanush_productions.drawingapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var drawingClass: DrawingClass
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        setContentView(R.layout.activity_main,
            object : ViewFactory {
                override fun onCreateView(name: String, context: Context, attrs: AttributeSet): View {
                    return when(name) {
                        "com.kanush_productions.drawingapp.DrawingClass" -> DrawingClass(context, attrs)
                        else -> super.onCreateView(name, context, attrs)
                    }
                }
            })

        drawingClass = findViewById(R.id.drawing_space)
    }
}