package com.kanush_productions.drawingapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class DrawingClass(context: Context) : View(context) {
    constructor(context: Context, attrs: AttributeSet) : this(context)
    private var path = Path()

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val xPos = event.x
        val yPos = event.y

        when(event.action) {
            MotionEvent.ACTION_DOWN -> {
                path.moveTo(xPos, yPos)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                path.lineTo(xPos, yPos)
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }
    override fun onDraw(canvas: Canvas) {
        canvas.drawPath(path, Paint())
    }
}